/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package epurse;

/**
 *
 * @author MK_Utilisateur
 */
public class OperationList {
    /*
     *  This list is in fact a cycling array. An index (nextOp) indicates
     *  the next slot which can be used for storing a new operation,
     *  the added operation erase the oldest one, numberOp is the number
     *  of operations stored
     */
    public final static short EPURSE_MAXOP = (short)5;
    private Operation [] list = null;
    private short nextOp = (short)0;
    private short numberOp = (short)0;

    public OperationList(){
        /*  TODO
         *  Create an array of EPURSE_MAXOP Operations
         */
    }

    public short getNumberOp(){
        return numberOp;
    }

    public void addOperation(byte [] buffer, byte type, short offsetAmount){
        /*  TODO
         *  add a new operation
         */
    }

    public void getOperation(byte [] buffer, short offsetResult, short index){
        /*  TODO
         *  this method extracts the indexth operation and copy it into the
         *  buffer at offsetResult. The value of index id 0 for the more
         *  recent operation and EPURSE_MAXOP-1 for the oldest operation
         */
    }
}
